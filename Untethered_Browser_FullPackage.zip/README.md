# Untethered Browser

Minimal viable product for a Kivy-based Android browser app.

## Build Instructions

Use Buildozer to package this APK:

```
buildozer android debug
```
