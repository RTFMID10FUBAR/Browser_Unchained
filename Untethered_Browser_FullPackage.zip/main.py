from kivy.app import App
from kivy.uix.label import Label

class UntetheredBrowserApp(App):
    def build(self):
        return Label(text='Untethered Browser MVP Running!')

if __name__ == '__main__':
    UntetheredBrowserApp().run()
